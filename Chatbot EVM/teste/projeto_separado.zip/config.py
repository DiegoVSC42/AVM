from langchain_community.chat_models import ChatOllama

# Definindo a IA
llm = ChatOllama(model="mistral", temperature=0)