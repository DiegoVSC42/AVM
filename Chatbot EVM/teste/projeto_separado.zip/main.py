import textwrap
from config import llm
from prompts import criar_prompt_tradicional, criar_prompt_rag
from pdf_loader import carregar_pdf, juntar_conteudo, dividir_em_chunks

def executar_tradicional():
    pergunta = "Qual era o nome do cavalo de napoleão ?"
    contexto = "Responda a seguinte pergunta: "

    prompt_tradicional = criar_prompt_tradicional()
    prompt_pronto = prompt_tradicional.format(contexto=contexto, pergunta=pergunta)
    print(prompt_pronto)

    chain_tradicional = prompt_tradicional | llm
    resposta_tradicional = chain_tradicional.invoke({
        "contexto": contexto,
        "pergunta": pergunta
    })

    texto = str(resposta_tradicional.content)
    print("Pergunta:", pergunta)
    print("Resposta:", textwrap.fill(texto, width=75))

def executar_rag():
    docs = carregar_pdf(r"documentos/Perguntas Frequentes - Eu Vereador.pdf")
    contexto = juntar_conteudo(docs)
    chunks = dividir_em_chunks(docs)

    pergunta = "Qual a pergunta menos frequente ?"
    prompt_rag = criar_prompt_rag()
    prompt_rag_pronto = prompt_rag.format(contexto=contexto, pergunta=pergunta)
    print(prompt_rag_pronto)

    chain_rag = prompt_rag | llm
    resposta_rag = chain_rag.invoke({
        "contexto": contexto,
        "pergunta": pergunta
    })

    texto = str(resposta_rag.content)
    print("Pergunta:", pergunta)
    print("Resposta:", textwrap.fill(texto, width=75))

if __name__ == "__main__":
    executar_tradicional()
    executar_rag()