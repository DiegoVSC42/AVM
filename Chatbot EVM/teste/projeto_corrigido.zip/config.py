
from langchain_ollama import ChatOllama

# Definindo a IA
llm = ChatOllama(model="mistral", temperature=0)
